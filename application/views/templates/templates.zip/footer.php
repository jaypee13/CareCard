

	</div>	
    <!--
	<div class="card border-light mb-3" >
        <ul class="list-group list-group-flush">
          <li class="list-group-item" style="background-color:#F5F5F5"><b>BIRTH:&nbsp;</b> 
            
          </li>
          <li class="list-group-item"><b>HEIGHT:</b> </li>
          <li class="list-group-item" style="background-color:#F5F5F5"><b>HOME PHONE:</b> 
            
          </li>
          <li class="list-group-item"><b>INSURANCE COVERAGE: </b><br/> 
            
          </li>
          <li class="list-group-item" style="background-color:#F5F5F5"><b>EMERGENCY CONTACT: </b> <br/>
            <b>NAME:</b> <br/>
            <b>ADDRESS:</b> <br/>
            <b>NUMBER:</b> 
          </li>

          <small class="post-date" style="padding-left: 20px; color: Gray;">Registed:&nbsp;</small>
        </ul>
    </div>
      -->
  <script src="<?php echo base_url(); ?>public\jquery-3.3.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
  <script src="<?php echo base_url(); ?>public\popper.min.js"></script>
  <script src="<?php echo base_url(); ?>public\bootstrap.min.js"></script>
  <?php
    if ($this->uri->segment(1) === 'register') {
      ?>
      <script src="<?php echo base_url(); ?>public\register.js"></script>
      <?php
    }
  ?>
  </body>
</html>
