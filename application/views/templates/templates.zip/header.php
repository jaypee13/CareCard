<!doctype html>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    //<meta charset="utf-8" encoding="utf8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>public\bootstrap.min.css">

	  <!-- Custom styles for this template -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>public\OtherPublic\starter-template.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>public\OtherPublic\login.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Taytay Care Card</title>
    <style type="text/css">



    </style>
  </head>

  <body>
    <?php include("functions.php");
    login_session();  ?>

    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: darkred; padding-top: 0px; padding-bottom: 0px; border-bottom: 6px solid red;">
      <a class="navbar-brand" href="" class="imgcontainer">
      <img src="<?php echo base_url(); ?>public\images\taytayseal.png" style="magin: 0px; padding: 0px" >
      </a>
      <button class="navbar-toggler" style="max-width:60px" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse"  id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo base_url(); ?>home">Home</span></a>
          </li>
          <!--
          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" id="dropdown01" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Corporate Profile</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="<?php echo base_url(); ?>About">About Us</a>
              <a class="dropdown-item" href="<?php echo base_url(); ?>Mission">Mission</a>
              <a class="dropdown-item" href="<?php echo base_url(); ?>Vision">Vision</a>
              <a class="dropdown-item" href="<?php echo base_url(); ?>Board">Board of Directors</a>
            </div>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo base_url(); ?>posts">News & Announcements</a>
          </li>
          -->
          <li class="nav-item dropdown active">
            <a class="nav-link dropdown-toggle" id="dropdown02" href="https://example.com" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Membership</a>
            <div class="dropdown-menu" aria-labelledby="dropdown02">
              <a class="dropdown-item" href="<?php echo base_url(); ?>Benefits">Benefits</a>
              <a id="mnuConst" class="dropdown-item ahref-disabled" href="<?php echo base_url(); ?>constituents">Constituents</a>
              <a class="dropdown-item" href="<?php echo base_url(); ?>FAQs">FAQs</a>
            </div>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="<?php echo base_url(); ?>ContactUs">Contact Us</a>
          </li>
          <li class="nav-item active">
            <a href="<?php echo base_url() ?>register" class="nav-link">Register</a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          	<!--<input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
          	<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>-->
          	<ul class="navbar-nav mr-auto">
            <li class="nav-item dropdown active">
                <?php $UserName = $this->session->userdata('username'); 
                      $UserLevel = $this->session->userdata('intLevel'); 
                ?>
                <a class="nav-link dropdown-toggle" id="dropdown03" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php if ($UserName == "" || $UserName == "invalid") { ?>
                    <img src="<?php echo base_url(); ?>public\images\logout.png" style="height:40%; width:40%">
                  <?php }else { ?>
                    <img src="<?php echo base_url(); ?>public\images\login.png" style="height:40%; width:40%">
                  <?php } ?>
                </a>

                <?php echo isset($error) ? $error : ''; ?>  
                <div class="dropdown-menu dropdown-menu-right text-left" id="MenuDropDown" aria-labelledby="dropdown03">
                    <?php if ($UserName == "" || $UserName == "invalid") { ?>
                            <a id="mnuPartnerLogin" class="dropdown-item" href="#" onclick="document.getElementById('id01').style.display ='block'; $('.collapse').collapse('hide');">Account Login</a>
                            <?php $this->session->unset_userdata('user');  
                            $this->session->unset_userdata('username'); 
                            $this->session->unset_userdata('tmpLogtime'); 
                            $this->session->unset_userdata('intLevel');  ?> 
                    <?php }else { ?>
                            <a id="mnuPartnerLogin" class="dropdown-item" href="<?php echo site_url('Login/logout'); ?>" onclick="return confirm('Do you want to logout?')">Logout <?php echo ucwords(strtolower($UserName)); ?></a>
                    <?php } ?>

                    <!--
                    <a id="mnuUserPrf" class="dropdown-item ahref-disabled" href="<?php echo base_url(); ?>profile">User Profile</a>
                    -->
                    
                    <a id="mnuPassword" class="dropdown-item ahref-disabled" href="<?php echo base_url(); ?>password">Change Password</a>

                    <?php if ($UserLevel == ""){ ?>
                        <script>
                          document.getElementById('mnuConst').classList.remove('ahref-enabled');
                          document.getElementById('mnuConst').classList.add('ahref-disabled');
                          document.getElementById('mnuPassword').classList.remove('ahref-enabled');
                          document.getElementById('mnuPassword').classList.add('ahref-disabled');
                          document.getElementById('mnuUserPrf').classList.remove('ahref-enabled');
                          document.getElementById('mnuUserPrf').classList.add('ahref-disabled');
                        </script>
                    <?php } else { ?>
                        <script>
                          document.getElementById('mnuConst').classList.remove('ahref-disabled');
                          document.getElementById('mnuConst').classList.add('ahref-enabled');
                          document.getElementById('mnuPassword').classList.remove('ahref-disabled');
                          document.getElementById('mnuPassword').classList.add('ahref-enabled');
                          document.getElementById('mnuUserPrf').classList.remove('ahref-disabled');
                          document.getElementById('mnuUserPrf').classList.add('ahref-enabled');
                        </script>
                    <?php } ?>
                    
                </div>
            </li>
      		</ul>
        </form>
      </div>
    </nav>
    
    <div class="container-fluid">
        